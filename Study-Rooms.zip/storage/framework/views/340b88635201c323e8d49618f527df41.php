<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo notifyCss(); ?>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="<?php echo e(asset('assets/favicon.ico')); ?>" type="image/x-icon" />
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" />
    <title>StudyBuddy - Find study partners around the world!</title>
</head>

<body>

    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('dashboard'); ?>

    <?php echo $__env->yieldContent('index'); ?>

    <?php echo $__env->yieldContent('room_form'); ?>

    <?php echo $__env->yieldContent('room'); ?>

    <?php echo $__env->yieldContent('room_edit'); ?>

    <?php echo $__env->yieldContent('delete_room'); ?>

    <?php echo $__env->yieldContent('topics'); ?>

    <?php echo $__env->yieldContent('profile'); ?>


    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
    <?php echo notifyJs(); ?>
</body>

</html><?php /**PATH C:\laragon\www\Study-Rooms\resources\views/layouts/main.blade.php ENDPATH**/ ?>