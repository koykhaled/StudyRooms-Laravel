
<div class="room__conversation">
    <div class="threads scroll">
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="thread">
            <div class="thread__top">
                <div class="thread__author">
                    <a href="#" class="thread__authorInfo">
                        <div class="avatar avatar--small">
                            <img src="https://randomuser.me/api/portraits/men/37.jpg" />
                        </div>
                        <span>@dennis_ivy</span>
                    </a>
                    <span class="thread__date">3 day ago</span>
                </div>
                <div class="thread__delete">
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32"
                        viewBox="0 0 32 32">
                        <title>remove</title>
                        <path
                            d="M27.314 6.019l-1.333-1.333-9.98 9.981-9.981-9.981-1.333 1.333 9.981 9.981-9.981 9.98 1.333 1.333 9.981-9.98 9.98 9.98 1.333-1.333-9.98-9.98 9.98-9.981z">
                        </path>
                    </svg>
                </div>
            </div>
            <div class="thread__details">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque nobis, deserunt cum
                quibusdam aliquam
                nihil unde et impedit, quaerat! Corporis praesentium aspernatur autem laboriosam natus
                similique,
                adipisci nam maxime.
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div><?php /**PATH C:\laragon\www\Study-Rooms\resources\views/messages/index.blade.php ENDPATH**/ ?>