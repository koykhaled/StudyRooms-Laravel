<div class="activities">
    <div class="activities__header">
        <h2>Recent Activities</h2>
    </div>
    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="activities__box">
        <div class="activities__boxHeader roomListRoom__header">
            <a href="<?php echo e(route('profile.show',$message->user->uuid)); ?>" class="roomListRoom__author">
                <div class="avatar avatar--small">
                    <?php if($message->user->photo == null): ?>
                    <img src="<?php echo e(asset('assets/avatar.svg')); ?>" />
                    <?php else: ?>
                    <img src="<?php echo e(asset($message->user->photo)); ?>" />
                    <?php endif; ?>
                </div>
                <p>
                    <?php echo e($message->user->name); ?>

                    <span><?php echo e($message->created_at); ?></span>
                </p>
            </a>
            <?php if(auth()->user()->id == $message->user_id): ?>
            <div class="roomListRoom__actions">
                <a href="<?php echo e(route('message.destroy',$message->id)); ?>"
                    onclick="event.preventDefault(); document.getElementById('delete_message').submit();"
                    title="delete_message">
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32"
                        viewBox="0 0 32 32">
                        <title>remove</title>
                        <path
                            d="M27.314 6.019l-1.333-1.333-9.98 9.981-9.981-9.981-1.333 1.333 9.981 9.981-9.981 9.98 1.333 1.333 9.981-9.98 9.98 9.98 1.333-1.333-9.98-9.98 9.98-9.981z">
                        </path>
                    </svg>
                </a>
                <form id="delete_message" method="post" action="<?php echo e(route('message.destroy',$message->id)); ?>">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
            <?php endif; ?>
        </div>
        <div class="activities__boxContent">
            <p>replied to post “<a href="<?php echo e(route('rooms.show',$message->room->slug)); ?>"><?php echo e($message->room->name); ?></a>”</p>
            <div class="activities__boxRoomContent">
                <?php echo e($message->message); ?>

            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div><?php /**PATH C:\laragon\www\Study-Rooms\resources\views/rooms/active_component.blade.php ENDPATH**/ ?>