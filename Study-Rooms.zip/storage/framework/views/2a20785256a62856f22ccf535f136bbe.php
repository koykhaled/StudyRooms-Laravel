<?php $__env->startSection('profile'); ?>
<main class="profile-page layout layout--3">
  <div class="container">
    <!-- Topics Start -->
    <?php echo $__env->make('rooms.tobics_component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Topics End -->

    <!-- Room List Start -->
    <div class="roomList">
      <div class="profile">
        <div class="profile__avatar">
          <div class="avatar avatar--large active">
            <img src="https://randomuser.me/api/portraits/men/11.jpg" />
          </div>
        </div>
        <div class="profile__info">
          <h3><?php echo e(auth()->user()->name); ?></h3>
          <p><span>@</span><?php echo e(auth()->user()->name); ?></p>
          <?php if(request()->user() ==$user): ?>
          <a href="{%url 'update-profile'%}" class="btn btn--main btn--pill">Edit Profile</a>
          <?php endif; ?>
        </div>
        <div class="profile__about">
          <h3>About</h3>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur illo tenetur
            facilis sunt nemo debitis quisquam hic atque aut? Ducimus alias placeat optio
            accusamus repudiandae quis ab ex exercitationem rem?
          </p>
        </div>
      </div>

      <div class="roomList__header">
        <div>
          <h2>Study Rooms Hosted by <?php echo e(auth()->user()->name); ?></a>
          </h2>
        </div>
      </div>
      <?php echo $__env->make('rooms.room_component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- Room List End -->

    <!-- Activities Start -->
    <?php echo $__env->make('rooms.active_component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
    <!-- Activities End -->
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Study-Rooms\resources\views/rooms/profile.blade.php ENDPATH**/ ?>