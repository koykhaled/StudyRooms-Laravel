<?php $__env->startSection('profile'); ?>
<main class="profile-page layout layout--3">
    <div class="container">
        <!-- Topics Start -->
        <?php echo $__env->make('rooms.tobics_component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Topics End -->

        <!-- Room List Start -->

        <div class="roomList">
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'notify::components.notify','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('notify::notify'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <div class="profile">

                <div class="profile__avatar">
                    <div class="avatar avatar--large active">
                        <?php if($user->photo == null): ?>
                        <img src="<?php echo e(asset('assets/avatar.svg')); ?>" />
                        <?php else: ?>
                        <img src="<?php echo e(asset($user->photo)); ?>" />
                        <?php endif; ?>
                    </div>
                </div>
                <div class="profile__info">
                    <h3><?php echo e($user->name); ?></h3>
                    <p><span>@</span><?php echo e($user->name); ?></p>
                    <?php if(request()->user() ==$user): ?>
                    <a href="<?php echo e(route('profile.edit',$user->uuid)); ?>" class="btn btn--main btn--pill">Edit Profile</a>
                    <a href="<?php echo e(route('profile.delete',$user->uuid)); ?>" class="btn btn--main btn--pill"
                        style="color: red;">Delete
                        Profile</a>
                    <?php endif; ?>
                </div>
                <div class="profile__about">
                    <h3>About</h3>
                    <p>
                        <?php echo e($user->description); ?>

                    </p>
                </div>
            </div>
            <?php if(count($rooms)): ?>
            <div class="roomList__header">
                <div>
                    <h2>Study Rooms Hosted by <?php echo e($user->name); ?></a>
                    </h2>
                </div>
            </div>
            <?php echo $__env->make('rooms.room_component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
        <!-- Room List End -->

        <!-- Activities Start -->
        <?php echo $__env->make('rooms.active_component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Activities End -->
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Study-Rooms\resources\views/profile/profile.blade.php ENDPATH**/ ?>