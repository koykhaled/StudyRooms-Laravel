<div class="topics">
    <div class="topics__header">
        <h2>Browse Topics</h2>
    </div>
    <ul class="topics__list">
        <li>
            <a href="<?php echo e(route('topics.index')); ?>" class="active">All <span><?php echo e($topics_count); ?></span></a>
        </li>
        <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('rooms.index')); ?>?topic_id=<?php echo e($topic->id); ?>" class="active"><?php echo e($topic->name); ?> <span><?php echo e($topic->rooms_count); ?></span></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php if($topics_count > 3): ?>
        <a class="btn btn--link" href="<?php echo e(route('topics.index')); ?>">
            More
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
                <title>chevron-down</title>
                <path d="M16 21l-13-13h-3l16 16 16-16h-3l-13 13z"></path>
            </svg>
        </a>
    <?php endif; ?>

</div><?php /**PATH C:\laragon\www\Study-Rooms\resources\views/rooms/tobics_component.blade.php ENDPATH**/ ?>